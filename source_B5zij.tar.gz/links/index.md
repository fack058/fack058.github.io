---
title: link
comments: false
date: 2024-05-31 22:43:43
type: link
---
<div id="qexo-friends"></div>
<link rel="stylesheet" href="https://unpkg.com/qexo-friends/friends.css"/>
<script src="https://registry.npmmirror.com/qexo-static/1.6.0/files/hexo/friends.js"></script>
<script>loadQexoFriends("qexo-friends", "http://192.168.137.6:11111")</script>